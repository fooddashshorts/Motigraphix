import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { Editor } from './pages/Editor';
import { Templates } from './pages/Templates';
import { Pricing } from './pages/Pricing';
import { Tutorials } from './pages/Tutorials';
import { Footer } from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white font-inter">
        <Navigation />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/editor" element={<Editor />} />
            <Route path="/templates" element={<Templates />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/tutorials" element={<Tutorials />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;