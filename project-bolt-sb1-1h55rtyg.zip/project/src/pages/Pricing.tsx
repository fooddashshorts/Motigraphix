import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Check, 
  Star, 
  Zap, 
  Crown, 
  Sparkles,
  X,
  ArrowRight,
  Users,
  Download,
  Clock
} from 'lucide-react';

export function Pricing() {
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      name: 'Free',
      description: 'Perfect for getting started',
      monthlyPrice: 0,
      annualPrice: 0,
      icon: Star,
      gradient: 'from-gray-500 to-gray-600',
      features: [
        '5 renders per month',
        'Up to 1 minute videos',
        'Watermarked exports',
        'Standard AI model',
        '5 downloads per month',
        '4 basic style presets'
      ],
      limitations: [
        'Watermark on exports',
        'Limited style presets',
        'Standard support'
      ],
      cta: 'Get Started Free',
      popular: false
    },
    {
      name: 'Starter',
      description: 'For growing creators',
      monthlyPrice: 10.99,
      annualPrice: 9.99,
      icon: Zap,
      gradient: 'from-orange-500 to-yellow-500',
      features: [
        '20 renders per month',
        'Up to 5 minute videos',
        'No watermark',
        'Enhanced AI model',
        'Unlimited downloads',
        '16 style presets',
        'Save up to 10 templates'
      ],
      limitations: [],
      cta: 'Start Creating',
      popular: true
    },
    {
      name: 'Premium',
      description: 'For professional creators',
      monthlyPrice: 30.99,
      annualPrice: 24.99,
      icon: Crown,
      gradient: 'from-purple-600 to-pink-600',
      features: [
        'Unlimited renders',
        'Up to 30 minute videos',
        'No watermark',
        'Priority AI access',
        'All export formats',
        '50+ style presets',
        'Unlimited template saving',
        'Advanced timeline editor',
        'Beta feature access'
      ],
      limitations: [],
      cta: 'Go Premium',
      popular: false
    }
  ];

  const faqs = [
    {
      question: 'What happens when I exceed my monthly render limit?',
      answer: 'You can upgrade your plan at any time or wait until the next billing cycle. We never charge overage fees.'
    },
    {
      question: 'Can I cancel my subscription anytime?',
      answer: 'Yes! You can cancel your subscription through your account settings. Easy unsubscribing is powered by Stripe Customer Portal.'
    },
    {
      question: 'What export formats are supported?',
      answer: 'We support MP4, GIF, WebM, and Lottie JSON formats. Premium users get access to additional formats and quality options.'
    },
    {
      question: 'Do you offer refunds?',
      answer: 'We offer a 30-day money-back guarantee for all paid plans. Contact support if you\'re not satisfied.'
    },
    {
      question: 'Can I change my plan later?',
      answer: 'Absolutely! You can upgrade or downgrade your plan at any time through your account dashboard.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 via-yellow-50 to-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              Choose Your Creative Journey
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Flexible plans designed to grow with your creative needs
            </p>
            
            {/* Billing Toggle */}
            <div className="inline-flex items-center bg-white rounded-xl p-1 border border-gray-200 mb-12">
              <button
                onClick={() => setIsAnnual(false)}
                className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 ${
                  !isAnnual
                    ? 'bg-gradient-orange text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setIsAnnual(true)}
                className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 relative ${
                  isAnnual
                    ? 'bg-gradient-orange text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Annual
                <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">
                  Save 20%
                </span>
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`relative bg-white rounded-2xl shadow-sm border-2 ${
                  plan.popular
                    ? 'border-orange-200 shadow-xl scale-105'
                    : 'border-gray-200'
                } overflow-hidden hover:shadow-xl transition-all duration-300`}
              >
                {plan.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-orange text-white text-center py-2 text-sm font-semibold">
                    Most Popular
                  </div>
                )}
                
                <div className={`p-8 ${plan.popular ? 'pt-12' : ''}`}>
                  {/* Header */}
                  <div className="text-center mb-8">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${plan.gradient} flex items-center justify-center mx-auto mb-4`}>
                      <plan.icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                    <p className="text-gray-600 mb-4">{plan.description}</p>
                    
                    <div className="mb-6">
                      <span className="text-4xl font-bold text-gray-900">
                        ${isAnnual ? plan.annualPrice : plan.monthlyPrice}
                      </span>
                      {plan.monthlyPrice > 0 && (
                        <span className="text-gray-600">
                          /{isAnnual ? 'mo' : 'month'}
                        </span>
                      )}
                      {isAnnual && plan.monthlyPrice > 0 && (
                        <div className="text-sm text-green-600 mt-1">
                          Billed annually (${(isAnnual ? plan.annualPrice : plan.monthlyPrice) * 12}/year)
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Features */}
                  <div className="space-y-3 mb-8">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                    {plan.limitations.map((limitation, idx) => (
                      <div key={idx} className="flex items-center opacity-60">
                        <X className="w-5 h-5 text-gray-400 mr-3 flex-shrink-0" />
                        <span className="text-gray-500 line-through">{limitation}</span>
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  <button
                    className={`w-full py-3 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
                      plan.popular
                        ? 'bg-gradient-orange text-white hover:shadow-lg hover:scale-105'
                        : 'bg-gray-900 text-white hover:bg-gray-800'
                    }`}
                  >
                    <span>{plan.cta}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Compare All Features
            </h2>
            <p className="text-xl text-gray-600">
              See exactly what's included in each plan
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 pr-4 font-semibold text-gray-900">Features</th>
                  <th className="text-center py-4 px-4 font-semibold text-gray-900">Free</th>
                  <th className="text-center py-4 px-4 font-semibold text-gray-900">Starter</th>
                  <th className="text-center py-4 px-4 font-semibold text-gray-900">Premium</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {[
                  { feature: 'Monthly Renders', free: '5', starter: '20', premium: 'Unlimited' },
                  { feature: 'Video Duration', free: '1 min', starter: '5 min', premium: '30 min' },
                  { feature: 'Watermark', free: 'Yes', starter: 'No', premium: 'No' },
                  { feature: 'AI Model', free: 'Standard', starter: 'Enhanced', premium: 'Priority' },
                  { feature: 'Style Presets', free: '4', starter: '16', premium: '50+' },
                  { feature: 'Export Formats', free: 'MP4, GIF', starter: 'All formats', premium: 'All formats' },
                  { feature: 'Template Saving', free: 'No', starter: '10', premium: 'Unlimited' },
                  { feature: 'Timeline Editor', free: 'No', starter: 'Basic', premium: 'Advanced' },
                  { feature: 'Beta Features', free: 'No', starter: 'No', premium: 'Yes' },
                ].map((row, index) => (
                  <tr key={index}>
                    <td className="py-4 pr-4 font-medium text-gray-900">{row.feature}</td>
                    <td className="text-center py-4 px-4 text-gray-600">{row.free}</td>
                    <td className="text-center py-4 px-4 text-gray-600">{row.starter}</td>
                    <td className="text-center py-4 px-4 text-gray-600">{row.premium}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-600">
              Everything you need to know about our pricing
            </p>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {faq.question}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {faq.answer}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600 to-yellow-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to create amazing animations?
            </h2>
            <p className="text-xl text-orange-100 mb-8">
              Join thousands of creators who trust Motigraphix for their motion graphics
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-4 bg-white text-orange-600 font-semibold rounded-xl hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2">
                <Sparkles className="w-5 h-5" />
                <span>Start Free Trial</span>
              </button>
              <button className="px-8 py-4 bg-transparent border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-orange-600 transition-all duration-300">
                Contact Sales
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}