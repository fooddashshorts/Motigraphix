import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Star, 
  Download, 
  Play, 
  Heart, 
  Eye,
  Clock,
  Zap,
  Sparkles,
  Palette,
  Type,
  Wand2
} from 'lucide-react';

export function Templates() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStyle, setSelectedStyle] = useState('all');

  const categories = [
    { id: 'all', name: 'All Templates', count: 150 },
    { id: 'text', name: 'Text Animations', count: 45 },
    { id: 'logo', name: 'Logo Reveals', count: 30 },
    { id: 'social', name: 'Social Media', count: 25 },
    { id: 'business', name: 'Business', count: 20 },
    { id: 'creative', name: 'Creative', count: 30 },
  ];

  const styles = [
    { id: 'all', name: 'All Styles' },
    { id: 'minimal', name: 'Minimal' },
    { id: 'modern', name: 'Modern' },
    { id: 'elegant', name: 'Elegant' },
    { id: 'bold', name: 'Bold' },
    { id: 'playful', name: 'Playful' },
  ];

  const templates = [
    {
      id: 1,
      title: 'Glitch Text Reveal',
      category: 'text',
      style: 'modern',
      preview: 'https://images.pexels.com/photos/6153354/pexels-photo-6153354.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '3s',
      downloads: 1234,
      rating: 4.8,
      isPro: false,
      tags: ['glitch', 'reveal', 'modern'],
      description: 'Dynamic glitch effect with smooth text reveal animation'
    },
    {
      id: 2,
      title: 'Neon Logo Intro',
      category: 'logo',
      style: 'bold',
      preview: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '5s',
      downloads: 892,
      rating: 4.9,
      isPro: true,
      tags: ['neon', 'logo', 'intro'],
      description: 'Vibrant neon glow effect perfect for logo introductions'
    },
    {
      id: 3,
      title: 'Typewriter Effect',
      category: 'text',
      style: 'minimal',
      preview: 'https://images.pexels.com/photos/1194713/pexels-photo-1194713.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '4s',
      downloads: 756,
      rating: 4.7,
      isPro: false,
      tags: ['typewriter', 'classic', 'text'],
      description: 'Classic typewriter animation with authentic typing sounds'
    },
    {
      id: 4,
      title: 'Particle Explosion',
      category: 'creative',
      style: 'playful',
      preview: 'https://images.pexels.com/photos/3137078/pexels-photo-3137078.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '6s',
      downloads: 1056,
      rating: 4.8,
      isPro: true,
      tags: ['particles', 'explosion', 'dynamic'],
      description: 'Explosive particle effects with customizable colors'
    },
    {
      id: 5,
      title: 'Social Media Story',
      category: 'social',
      style: 'modern',
      preview: 'https://images.pexels.com/photos/267389/pexels-photo-267389.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '15s',
      downloads: 2341,
      rating: 4.9,
      isPro: true,
      tags: ['instagram', 'story', 'social'],
      description: 'Perfect for Instagram stories and social media content'
    },
    {
      id: 6,
      title: 'Business Presentation',
      category: 'business',
      style: 'elegant',
      preview: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '8s',
      downloads: 567,
      rating: 4.6,
      isPro: false,
      tags: ['business', 'corporate', 'clean'],
      description: 'Professional animation for business presentations'
    },
    {
      id: 7,
      title: 'Smooth Slide Transition',
      category: 'text',
      style: 'minimal',
      preview: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '3s',
      downloads: 834,
      rating: 4.7,
      isPro: false,
      tags: ['slide', 'smooth', 'transition'],
      description: 'Elegant sliding animation with smooth transitions'
    },
    {
      id: 8,
      title: 'Creative Title Card',
      category: 'creative',
      style: 'bold',
      preview: 'https://images.pexels.com/photos/3861972/pexels-photo-3861972.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '4s',
      downloads: 923,
      rating: 4.8,
      isPro: true,
      tags: ['title', 'creative', 'bold'],
      description: 'Eye-catching title card with creative effects'
    },
    {
      id: 9,
      title: 'Zoom In Pop',
      category: 'text',
      style: 'playful',
      preview: 'https://images.pexels.com/photos/3861458/pexels-photo-3861458.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      duration: '2s',
      downloads: 1445,
      rating: 4.9,
      isPro: false,
      tags: ['zoom', 'pop', 'dynamic'],
      description: 'Dynamic zoom effect with satisfying pop animation'
    }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    const matchesStyle = selectedStyle === 'all' || template.style === selectedStyle;
    
    return matchesSearch && matchesCategory && matchesStyle;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Template Gallery</h1>
          <p className="text-gray-600">Discover professional motion graphics templates for every need</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>

            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name} ({category.count})
                </option>
              ))}
            </select>

            {/* Style Filter */}
            <select
              value={selectedStyle}
              onChange={(e) => setSelectedStyle(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              {styles.map(style => (
                <option key={style.id} value={style.id}>
                  {style.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template, index) => (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 group"
            >
              {/* Preview */}
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={template.preview}
                  alt={template.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <button className="bg-white text-gray-900 rounded-full p-3 hover:scale-110 transition-transform duration-200">
                    <Play className="w-6 h-6" />
                  </button>
                </div>

                {/* Pro Badge */}
                {template.isPro && (
                  <div className="absolute top-3 left-3 bg-gradient-orange text-white px-2 py-1 rounded-md text-xs font-semibold flex items-center space-x-1">
                    <Zap className="w-3 h-3" />
                    <span>PRO</span>
                  </div>
                )}

                {/* Duration */}
                <div className="absolute top-3 right-3 bg-black/70 text-white px-2 py-1 rounded-md text-xs font-medium flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>{template.duration}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
                  {template.title}
                </h3>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                  {template.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {template.tags.slice(0, 3).map(tag => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-md"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span>{template.rating}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Download className="w-4 h-4" />
                      <span>{template.downloads.toLocaleString()}</span>
                    </div>
                  </div>
                  <button className="text-gray-400 hover:text-red-500 transition-colors">
                    <Heart className="w-4 h-4" />
                  </button>
                </div>

                {/* Actions */}
                <div className="flex space-x-2">
                  <button className="flex-1 px-4 py-2 bg-gradient-orange text-white font-medium rounded-lg hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2">
                    <Download className="w-4 h-4" />
                    <span>Use Template</span>
                  </button>
                  <button className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* No Results */}
        {filteredTemplates.length === 0 && (
          <div className="text-center py-12">
            <Sparkles className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No templates found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your search or filters</p>
            <button 
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedStyle('all');
              }}
              className="px-6 py-3 bg-gradient-orange text-white font-medium rounded-lg hover:shadow-lg transition-all duration-200"
            >
              Clear Filters
            </button>
          </div>
        )}

        {/* Load More */}
        {filteredTemplates.length > 0 && (
          <div className="text-center mt-12">
            <button className="px-8 py-3 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors">
              Load More Templates
            </button>
          </div>
        )}
      </div>
    </div>
  );
}