import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  BookOpen, 
  Clock, 
  Star, 
  Search,
  Filter,
  Users,
  Award,
  Zap,
  Wand2,
  Settings,
  Download,
  Eye,
  ChevronRight
} from 'lucide-react';
import ReactPlayer from 'react-player';

export function Tutorials() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');

  const categories = [
    { id: 'all', name: 'All Topics', count: 45 },
    { id: 'getting-started', name: 'Getting Started', count: 8 },
    { id: 'ai-prompts', name: 'AI Prompts', count: 12 },
    { id: 'templates', name: 'Templates', count: 10 },
    { id: 'export', name: 'Export & Formats', count: 6 },
    { id: 'advanced', name: 'Advanced Techniques', count: 9 },
  ];

  const levels = [
    { id: 'all', name: 'All Levels' },
    { id: 'beginner', name: 'Beginner' },
    { id: 'intermediate', name: 'Intermediate' },
    { id: 'advanced', name: 'Advanced' },
  ];

  const tutorials = [
    {
      id: 1,
      title: 'Your First Animation: From Prompt to Export',
      description: 'Learn how to create your first motion graphics animation using AI prompts and export it in multiple formats.',
      type: 'video',
      category: 'getting-started',
      level: 'beginner',
      duration: '8:30',
      views: 12450,
      rating: 4.9,
      thumbnail: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      tags: ['basics', 'ai', 'export'],
      featured: true
    },
    {
      id: 2,
      title: 'Understanding the Motigraphix.app Interface',
      description: 'Complete walkthrough of the editor interface, panels, and navigation.',
      type: 'article',
      category: 'getting-started',
      level: 'beginner',
      duration: '5 min read',
      views: 8920,
      rating: 4.8,
      thumbnail: 'https://images.pexels.com/photos/3861458/pexels-photo-3861458.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      tags: ['interface', 'navigation', 'ui'],
      featured: false
    },
    {
      id: 3,
      title: 'Writing Effective AI Prompts for Animation',
      description: 'Master the art of crafting AI prompts that generate exactly the animations you envision.',
      type: 'video',
      category: 'ai-prompts',
      level: 'intermediate',
      duration: '12:15',
      views: 15680,
      rating: 4.9,
      thumbnail: 'https://images.pexels.com/photos/3861972/pexels-photo-3861972.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      tags: ['ai', 'prompts', 'tips'],
      featured: true
    },
    {
      id: 4,
      title: 'Using the Split-Pane Editor: Controls and Live Preview',
      description: 'Deep dive into the editor\'s split-pane layout and how to use real-time preview effectively.',
      type: 'video',
      category: 'getting-started',
      level: 'beginner',
      duration: '10:45',
      views: 9340,
      rating: 4.7,
      thumbnail: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      tags: ['editor', 'preview', 'workflow'],
      featured: false
    },
    {
      id: 5,
      title: 'Exploring Lottie Templates and Customization',
      description: 'Learn how to browse, select, and customize Lottie templates for your projects.',
      type: 'article',
      category: 'templates',
      level: 'intermediate',
      duration: '7 min read',
      views: 7650,
      rating: 4.8,
      thumbnail: 'https://images.pexels.com/photos/267389/pexels-photo-267389.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      tags: ['lottie', 'templates', 'customization'],
      featured: false
    },
    {
      id: 6,
      title: 'Working with Style Presets for MP4/GIF Exports',
      description: 'Complete guide to using and customizing style presets for different export formats.',
      type: 'video',
      category: 'export',
      level: 'intermediate',
      duration: '14:20',
      views: 11230,
      rating: 4.9,
      thumbnail: 'https://images.pexels.com/photos/3137078/pexels-photo-3137078.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      tags: ['presets', 'export', 'mp4', 'gif'],
      featured: true
    },
    {
      id: 7,
      title: 'Leveraging Advanced AI Models for Complex Scenes',
      description: 'Premium techniques for using advanced AI models to create sophisticated animations.',
      type: 'video',
      category: 'advanced',
      level: 'advanced',
      duration: '18:35',
      views: 5420,
      rating: 4.9,
      thumbnail: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      tags: ['ai', 'advanced', 'premium'],
      featured: false,
      isPremium: true
    },
    {
      id: 8,
      title: 'Exporting for Different Platforms',
      description: 'Best practices for optimizing exports for social media, web, and presentations.',
      type: 'article',
      category: 'export',
      level: 'intermediate',
      duration: '6 min read',
      views: 8920,
      rating: 4.7,
      thumbnail: 'https://images.pexels.com/photos/6153354/pexels-photo-6153354.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&fit=crop',
      tags: ['export', 'optimization', 'platforms'],
      featured: false
    }
  ];

  const filteredTutorials = tutorials.filter(tutorial => {
    const matchesSearch = tutorial.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tutorial.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tutorial.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || tutorial.category === selectedCategory;
    const matchesLevel = selectedLevel === 'all' || tutorial.level === selectedLevel;
    
    return matchesSearch && matchesCategory && matchesLevel;
  });

  const featuredTutorials = tutorials.filter(t => t.featured);

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Header */}
      <section className="bg-gradient-to-br from-orange-50 via-yellow-50 to-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              Learning Center
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Master Motigraphix with our comprehensive tutorials and guides
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="flex items-center space-x-2 text-gray-600">
                <Play className="w-5 h-5" />
                <span>25+ Video Tutorials</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <BookOpen className="w-5 h-5" />
                <span>20+ Written Guides</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Users className="w-5 h-5" />
                <span>50K+ Students</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Featured Tutorials */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Featured Tutorials</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredTutorials.map((tutorial, index) => (
              <motion.div
                key={tutorial.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 group"
              >
                <div className="relative aspect-video overflow-hidden">
                  <img
                    src={tutorial.thumbnail}
                    alt={tutorial.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <button className="bg-white text-gray-900 rounded-full p-3 hover:scale-110 transition-transform duration-200">
                      {tutorial.type === 'video' ? <Play className="w-6 h-6" /> : <BookOpen className="w-6 h-6" />}
                    </button>
                  </div>
                  
                  <div className="absolute top-3 left-3 bg-gradient-orange text-white px-2 py-1 rounded-md text-xs font-semibold">
                    Featured
                  </div>
                  
                  <div className="absolute top-3 right-3 bg-black/70 text-white px-2 py-1 rounded-md text-xs font-medium flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{tutorial.duration}</span>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                      tutorial.type === 'video' 
                        ? 'bg-red-100 text-red-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {tutorial.type === 'video' ? 'Video' : 'Article'}
                    </span>
                    <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                      tutorial.level === 'beginner' 
                        ? 'bg-green-100 text-green-800'
                        : tutorial.level === 'intermediate'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}>
                      {tutorial.level}
                    </span>
                    {tutorial.isPremium && (
                      <span className="px-2 py-1 bg-gradient-orange text-white rounded-md text-xs font-medium">
                        PRO
                      </span>
                    )}
                  </div>

                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-orange-600 transition-colors">
                    {tutorial.title}
                  </h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-3">
                    {tutorial.description}
                  </p>

                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span>{tutorial.rating}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Eye className="w-4 h-4" />
                        <span>{tutorial.views.toLocaleString()}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-orange-600 transition-colors" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search tutorials..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>

            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name} ({category.count})
                </option>
              ))}
            </select>

            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              {levels.map(level => (
                <option key={level.id} value={level.id}>
                  {level.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* All Tutorials */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-8">All Tutorials</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTutorials.map((tutorial, index) => (
              <motion.div
                key={tutorial.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 group"
              >
                <div className="relative aspect-video overflow-hidden">
                  <img
                    src={tutorial.thumbnail}
                    alt={tutorial.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <button className="bg-white text-gray-900 rounded-full p-3 hover:scale-110 transition-transform duration-200">
                      {tutorial.type === 'video' ? <Play className="w-6 h-6" /> : <BookOpen className="w-6 h-6" />}
                    </button>
                  </div>
                  
                  {tutorial.featured && (
                    <div className="absolute top-3 left-3 bg-gradient-orange text-white px-2 py-1 rounded-md text-xs font-semibold">
                      Featured
                    </div>
                  )}
                  
                  <div className="absolute top-3 right-3 bg-black/70 text-white px-2 py-1 rounded-md text-xs font-medium flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{tutorial.duration}</span>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                      tutorial.type === 'video' 
                        ? 'bg-red-100 text-red-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {tutorial.type === 'video' ? 'Video' : 'Article'}
                    </span>
                    <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                      tutorial.level === 'beginner' 
                        ? 'bg-green-100 text-green-800'
                        : tutorial.level === 'intermediate'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}>
                      {tutorial.level}
                    </span>
                    {tutorial.isPremium && (
                      <span className="px-2 py-1 bg-gradient-orange text-white rounded-md text-xs font-medium">
                        PRO
                      </span>
                    )}
                  </div>

                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-orange-600 transition-colors">
                    {tutorial.title}
                  </h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-3">
                    {tutorial.description}
                  </p>

                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span>{tutorial.rating}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Eye className="w-4 h-4" />
                        <span>{tutorial.views.toLocaleString()}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-orange-600 transition-colors" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Learning Paths */}
        <section className="mt-20">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Learning Paths</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mr-4">
                  <Wand2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Beginner's Journey</h3>
                  <p className="text-sm text-gray-600">Start from zero to creating your first animation</p>
                </div>
              </div>
              <div className="space-y-3">
                {['Interface Basics', 'First Animation', 'AI Prompts 101', 'Export Fundamentals'].map((step, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                      {index + 1}
                    </div>
                    <span className="text-gray-700">{step}</span>
                  </div>
                ))}
              </div>
              <button className="mt-6 w-full px-4 py-2 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors">
                Start Learning Path
              </button>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-200">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center mr-4">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Advanced Mastery</h3>
                  <p className="text-sm text-gray-600">Become a motion graphics expert</p>
                </div>
              </div>
              <div className="space-y-3">
                {['Complex AI Prompts', 'Timeline Mastery', 'Advanced Effects', 'Professional Workflows'].map((step, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                      {index + 1}
                    </div>
                    <span className="text-gray-700">{step}</span>
                  </div>
                ))}
              </div>
              <button className="mt-6 w-full px-4 py-2 bg-purple-500 text-white font-medium rounded-lg hover:bg-purple-600 transition-colors">
                Start Learning Path
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}