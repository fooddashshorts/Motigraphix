import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Download, 
  Settings, 
  Wand2, 
  Clock, 
  Palette, 
  Type,
  RefreshCw,
  Save,
  Share2,
  Maximize,
  RotateCcw,
  Zap
} from 'lucide-react';
import Lottie from 'lottie-react';

export function Editor() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPreset, setCurrentPreset] = useState('glitchFade');
  const [duration, setDuration] = useState(5);
  const [exportFormat, setExportFormat] = useState('mp4');
  const lottieRef = useRef(null);

  const presets = [
    { id: 'glitchFade', name: 'Glitch Fade', description: 'Digital glitch transition effect' },
    { id: 'bounceReveal', name: 'Bounce Reveal', description: 'Bouncy text reveal animation' },
    { id: 'typewriter', name: 'Typewriter', description: 'Classic typing animation' },
    { id: 'zoomPop', name: 'Zoom Pop', description: 'Dynamic zoom and pop effect' },
    { id: 'neonGlow', name: 'Neon Glow', description: 'Glowing neon light effect' },
    { id: 'smoothSlide', name: 'Smooth Slide', description: 'Elegant sliding transition' },
  ];

  const durations = [
    { value: 1, label: '1 minute' },
    { value: 3, label: '3 minutes' },
    { value: 5, label: '5 minutes' },
    { value: 10, label: '10 minutes' },
    { value: 20, label: '20 minutes' },
    { value: 30, label: '30 minutes' },
  ];

  // Mock Lottie animation data
  const mockLottieData = {
    v: "5.7.4",
    fr: 30,
    ip: 0,
    op: 150,
    w: 800,
    h: 600,
    nm: "AI Generated Animation",
    ddd: 0,
    assets: [],
    layers: [
      {
        ddd: 0,
        ind: 1,
        ty: 5,
        nm: "Text Layer",
        sr: 1,
        ks: {
          o: { a: 0, k: 100 },
          r: { a: 0, k: 0 },
          p: { a: 0, k: [400, 300, 0] },
          a: { a: 0, k: [0, 0, 0] },
          s: { a: 1, k: [
            { i: { x: [0.833], y: [0.833] }, o: { x: [0.167], y: [0.167] }, t: 0, s: [0, 0, 100] },
            { t: 30, s: [100, 100, 100] }
          ]}
        },
        ao: 0,
        t: {
          d: {
            k: [
              {
                s: {
                  s: 72,
                  f: "Arial",
                  t: prompt || "Your AI Animation",
                  j: 2,
                  tr: 0,
                  lh: 86.4,
                  ls: 0,
                  fc: [0.94, 0.45, 0.09]
                },
                t: 0
              }
            ]
          },
          p: {},
          m: { g: 1, a: { a: 0, k: [0, 0] } },
          a: []
        },
        ip: 0,
        op: 150,
        st: 0,
        bm: 0
      }
    ],
    markers: []
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsGenerating(false);
    setIsPlaying(true);
  };

  const handlePlayPause = () => {
    if (lottieRef.current) {
      if (isPlaying) {
        lottieRef.current.pause();
      } else {
        lottieRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleExport = () => {
    // Mock export functionality
    console.log(`Exporting as ${exportFormat} with preset ${currentPreset} for ${duration} minutes`);
    alert(`Exporting your animation as ${exportFormat.toUpperCase()}...`);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Motion Graphics Editor</h1>
          <p className="text-gray-600">Transform your ideas into stunning animations with AI-powered tools</p>
        </div>

        {/* Main Editor Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls Panel */}
          <div className="space-y-6">
            {/* Prompt Input */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Wand2 className="w-5 h-5 mr-2 text-orange-600" />
                AI Prompt
              </h2>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe your animation idea... (e.g., 'A glowing welcome text that bounces in with particle effects')"
                className="w-full h-32 p-4 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
              <button
                onClick={handleGenerate}
                disabled={!prompt.trim() || isGenerating}
                className="mt-4 w-full px-6 py-3 bg-gradient-orange text-white font-semibold rounded-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center space-x-2"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Generating...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    <span>Generate Animation</span>
                  </>
                )}
              </button>
            </div>

            {/* Style Presets */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Palette className="w-5 h-5 mr-2 text-orange-600" />
                Style Presets
              </h2>
              <div className="grid grid-cols-2 gap-3">
                {presets.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setCurrentPreset(preset.id)}
                    className={`p-3 text-left rounded-lg border-2 transition-all duration-200 ${
                      currentPreset === preset.id
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-orange-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="font-medium text-gray-900 text-sm">{preset.name}</div>
                    <div className="text-xs text-gray-600 mt-1">{preset.description}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Duration & Export Settings */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Settings className="w-5 h-5 mr-2 text-orange-600" />
                Export Settings
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Duration</label>
                  <select
                    value={duration}
                    onChange={(e) => setDuration(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    {durations.map((d) => (
                      <option key={d.value} value={d.value}>{d.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Export Format</label>
                  <select
                    value={exportFormat}
                    onChange={(e) => setExportFormat(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="mp4">MP4 Video</option>
                    <option value="gif">GIF Animation</option>
                    <option value="lottie">Lottie JSON</option>
                    <option value="webm">WebM Video</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleExport}
                className="mt-4 w-full px-6 py-3 bg-gray-900 text-white font-semibold rounded-lg hover:bg-gray-800 transition-colors flex items-center justify-center space-x-2"
              >
                <Download className="w-5 h-5" />
                <span>Export Animation</span>
              </button>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="space-y-6">
            {/* Main Preview */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-gray-900 px-6 py-4 flex items-center justify-between">
                <h2 className="text-white font-semibold">Live Preview</h2>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handlePlayPause}
                    className="p-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <button className="p-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors">
                    <RotateCcw className="w-4 h-4" />
                  </button>
                  <button className="p-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors">
                    <Maximize className="w-4 h-4" />
                  </button>
                </div>
              </div>
              
              <div className="aspect-video bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center relative">
                {prompt ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <Lottie
                      lottieRef={lottieRef}
                      animationData={mockLottieData}
                      loop={true}
                      autoplay={false}
                      className="w-full h-full max-w-md max-h-md"
                    />
                  </div>
                ) : (
                  <div className="text-center text-gray-400">
                    <Wand2 className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg">Enter a prompt to generate your animation</p>
                    <p className="text-sm mt-2">AI will create a preview based on your description</p>
                  </div>
                )}
              </div>

              {/* Timeline */}
              <div className="p-6 bg-gray-50 border-t">
                <div className="flex items-center space-x-4">
                  <Clock className="w-5 h-5 text-gray-600" />
                  <div className="flex-1">
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-orange w-1/4 rounded-full"></div>
                    </div>
                  </div>
                  <span className="text-sm text-gray-600">0:05 / 0:20</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4">
              <button className="px-6 py-3 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2">
                <Save className="w-4 h-4" />
                <span>Save Template</span>
              </button>
              <button className="px-6 py-3 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2">
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            </div>

            {/* Usage Stats */}
            <div className="bg-gradient-to-r from-orange-500 to-yellow-500 rounded-xl p-6 text-white">
              <h3 className="font-semibold mb-2">Usage This Month</h3>
              <div className="flex items-center justify-between mb-2">
                <span>Renders Used</span>
                <span className="font-bold">3 / 5</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2 mb-4">
                <div className="bg-white rounded-full h-2 w-3/5"></div>
              </div>
              <button className="w-full py-2 bg-white/20 hover:bg-white/30 rounded-lg font-medium transition-colors">
                Upgrade to Unlimited
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}